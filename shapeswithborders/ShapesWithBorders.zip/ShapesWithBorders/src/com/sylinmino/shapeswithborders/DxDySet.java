package com.sylinmino.shapeswithborders;

public class DxDySet {
	private int type = 0;
	
	public static final int VERTICAL = 1;
	public static final int HORIZONTAL = 2;
	public static final int SPIN = 4;
	public static final int SPIN_COUNTER = 8;
	
	public DxDySet(int type) {
		this.type = type;
	}
	
	public void setType(int type) {
		this.type = type;
	}
	
	public void getMovement(float[] outputV, float time, float rate) {
		if (outputV.length != 3) {
			return;
		}
		if (type % 2 == 1) {
			outputV[0] = (float)Math.sin(time * rate);
		} else {
			outputV[0] = 0;
		}
		if ((type % 4) >= 2) {
			outputV[1] = (float)Math.cos(0.9f * time * rate);
		} else {
			outputV[1] = 0;
		}
		if ((type % 8 >= 4) && type < 8) {
			outputV[3] = time * rate / 60.0f;
		} else if ((type % 8 >= 4) && type >= 8) {
			outputV[3] = -time * rate / 60.0f;
		}
	}
}
