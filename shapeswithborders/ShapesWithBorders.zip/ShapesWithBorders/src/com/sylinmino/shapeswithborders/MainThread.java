package com.sylinmino.shapeswithborders;

import android.os.SystemClock;
import android.util.Log;

public class MainThread extends Thread {

	private static final String TAG = MainThread.class.getSimpleName();
	
	private MyGLSurfaceView gamePanel;
	private boolean running;
	
	public void setRunning(boolean running) {
		this.running = running;
	}

	public MainThread(MyGLSurfaceView gamePanel) {
		super();
		this.gamePanel = gamePanel;
	}
 
	@Override
	public void run() {
		long tickCount = 0L;
		Log.d(TAG, "Starting game loop");
		long FPS = 60L;
        long delayFPS = 1000L / FPS;
		while (running) {
			tickCount++;
        	SystemClock.sleep(delayFPS);
        	gamePanel.updateAndDraw();
        	
        	gamePanel.downTime(FPS);
        	if (gamePanel.isLose) {
        		running = false;
        	}
	        }
		Log.d(TAG, "Game loop executed " + tickCount + " times");
		
	}
}
