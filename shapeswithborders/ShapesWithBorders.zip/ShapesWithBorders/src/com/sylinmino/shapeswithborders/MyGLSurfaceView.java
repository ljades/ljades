package com.sylinmino.shapeswithborders;


import java.util.Random;



import android.content.Context;
import android.opengl.GLSurfaceView;
import android.os.SystemClock;
import android.view.MotionEvent;

public class MyGLSurfaceView extends GLSurfaceView {
	
    private final MyGLRenderer mRenderer;
    private MainThread thread;
    public double max_count = 2.5;
    public double countdown;
    private boolean hasStarted;
    private int level;
    public final static String EXTRA_SCORE = "com.sylinmino.shapeswithborders.SCORE";
    public boolean isLose;
    
    private Random patternRand = new Random();
    
    private DxDySet pattern = new DxDySet(patternRand.nextInt(16));
    
    private Random levelRand = new Random();
    
    //private int [] textures;
    
    public int getLevel() {
    	return level;
    }
    
	public void updateAndDraw() {
		if (hasStarted) {
			float [] setOfMove = new float[3];
			pattern.getMovement(setOfMove, ((float)SystemClock.uptimeMillis() / 1000.0f), (float)Math.log(level + 1));
			mRenderer.setVelocityAndAngle(setOfMove[0], setOfMove[1], setOfMove[2]);
			requestRender();
		}
	}
	
	public void downTime(long FPS) {
		countdown -= 1.0 / (double)FPS;
		if (countdown <= 0.000001) {
			level++;
			countdown = max_count;
			isLose = false;
			hasStarted = false;
			//TODO: Display temporary wintext, delay time for two seconds
			mRenderer.setWinColor();
			requestRender();
			SystemClock.sleep(1000L);
			mRenderer.resetColor();
			mRenderer.setType((short)levelRand.nextInt(3));
			pattern.setType(patternRand.nextInt(16));
			mRenderer.setVelocityAndAngle(0, 0, 0);
		}
	}
    
    public MyGLSurfaceView(Context context){
        super(context);
        setEGLContextClientVersion(2);
        // Set the Renderer for drawing on the GLSurfaceView
        mRenderer = new MyGLRenderer();
        mRenderer.setType((short)0);
        setRenderer(mRenderer);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        countdown = max_count;
        hasStarted = false;
        level = 0;
        setFocusable(true);
        requestRender();
        thread = new MainThread(this);
        thread.start();
    }
    
    
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        // MotionEvent reports input details from the touch screen
        // and other input controls. In this case, you are only
        // interested in events where the touch position changed.
    	if (e.getPointerCount() > 1 && hasStarted == false) {
    		hasStarted = true;
    		float onefinger[] = {0.0f, 0.0f};
    		float twofinger[] = {0.0f, 0.0f};
    		onefinger[0] = e.getX(0);
    		onefinger[1] = e.getY(0);
    		twofinger[0] = e.getX(1);
    		twofinger[1] = e.getY(1);
    		boolean isDead = mRenderer.checkIntersect(onefinger) && mRenderer.checkIntersect(twofinger);
    		 
    		if (!isDead) {
    			//TODO: death condition
    			isLose = true;
    		}
    	} else {
    		if (hasStarted == true) {
    			//TODO: death condition
    			isLose = true;
    		}
    	}
        
        return true;
    }
}
