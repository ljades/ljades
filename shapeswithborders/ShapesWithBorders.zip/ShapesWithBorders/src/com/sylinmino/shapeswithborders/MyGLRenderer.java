package com.sylinmino.shapeswithborders;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import android.opengl.GLSurfaceView;
import android.opengl.GLES20;
import android.opengl.Matrix;
import android.util.Log;

public class MyGLRenderer implements GLSurfaceView.Renderer {
	private short currentType = 0;
	
	private static final String TAG = "MyGLRenderer";
	
	public static final short TRIANGLE = 0;
	public static final short SQUARE   = 1;
	public static final short CIRCLE   = 2;
	
	private float eyeX = 0.0f;
	private float eyeY = 0.0f;
	

    private float mAngle = 0.0f;
	
	private Triangle innerTriangle;
	private Triangle outerTriangle;
    private Square   innerSquare;
    private Square   outerSquare;
    private Circle   innerCircle;
    private Circle   outerCircle;
    
    private boolean isSetWin = false;
    
    private float colorBorder[] = { 1.0f, 1.0f, 1.0f, 1.0f };

    private float colorShape[] = { 1.0f, 0.0f, 1.0f, 1.0f };
    
    private float winBorder[] = { 0.8f, 1.0f, 0.8f, 1.0f };

    private float winShape[] = { 0.0f, 1.0f, 0.0f, 1.0f };
    
    // mMVPMatrix is an abbreviation for "Model View Projection Matrix"
    private final float[] mMVPMatrix = new float[16];
    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    private final float[] mRotationMatrix = new float[16];
    
    
    
    public void setType(short type) {
    	this.currentType = type;
    }
    
    //returns true if player is in valid territory, false if not
    public Boolean checkIntersect (float[] pointerCoords) {
    	float[] scratch = new float[16];
    	float[] invTrans = new float[16];
    	float[] pointVec = new float[4];
    	float[] invPoint = new float[4];
    	pointVec[0] = pointerCoords[0];
    	pointVec[1] = pointerCoords[1];
    	Matrix.multiplyMM(scratch, 0, mMVPMatrix, 0, mRotationMatrix, 0);
    	Matrix.invertM(invTrans, 0, scratch, 0);
    	Matrix.multiplyMV(invPoint, 0, invTrans, 0, pointVec, 0);
    	if (currentType == TRIANGLE) {
    		return outerTriangle.isIntersection(invPoint[0], invPoint[1]) && (!innerTriangle.isIntersection(invPoint[0], invPoint[1]));
    	} else if (currentType == SQUARE) {
    		return outerSquare.isIntersection(invPoint[0], invPoint[1]) && (!innerSquare.isIntersection(invPoint[0], invPoint[1]));
    	} else if (currentType == CIRCLE) {
    		return outerCircle.isIntersection(invPoint[0], invPoint[1]) && (!innerCircle.isIntersection(invPoint[0], invPoint[1]));
    	}
    	return true;
    }
    
    
    public void onSurfaceCreated(GL10 unused, EGLConfig config) {
        // Set the background frame color
        GLES20.glClearColor(0.7f, 0.7f, 1.0f, 1.0f);
        Matrix.setIdentityM(mRotationMatrix, 0);
        
        innerTriangle = new Triangle(1.0f);
        outerTriangle = new Triangle(1.3f);
        innerSquare = new Square(1.0f);
        outerSquare = new Square(1.3f);
        innerCircle = new Circle(1.0f);
        outerCircle = new Circle(1.3f);
    }

    public void onDrawFrame(GL10 unused) {
        // Redraw background color
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT);
        
        // Set the camera position (View matrix)
        Matrix.setLookAtM(mViewMatrix, 0, eyeX, eyeY, -3, eyeX, eyeY, 0f, 0f, 1.0f, 0.0f);

        // Calculate the projection and view transformation
        Matrix.multiplyMM(mMVPMatrix, 0, mProjectionMatrix, 0, mViewMatrix, 0);

        float[] scratch = new float[16];

        // Create a rotation transformation for the triangle
        /*long time = SystemClock.uptimeMillis() % 4000L;
        float angle = 0.090f * ((int) time);*/
        Matrix.setRotateM(mRotationMatrix, 0, mAngle, 0, 0, -1.0f);

        // Combine the rotation matrix with the projection and camera view
        // Note that the mMVPMatrix factor *must be first* in order
        // for the matrix multiplication product to be correct.
        Matrix.multiplyMM(scratch, 0, mMVPMatrix, 0, mRotationMatrix, 0);

        //TODO: Draw shape
        if (!isSetWin) {
	        if (currentType == TRIANGLE) {
	        	outerTriangle.draw(scratch, colorBorder);
	        	innerTriangle.draw(scratch, colorShape);
	        } else if (currentType == SQUARE) {
	        	outerSquare.draw(scratch, colorBorder);
	        	innerSquare.draw(scratch, colorShape);
	        } else {
	        	outerCircle.draw(scratch, colorBorder);
	        	innerCircle.draw(scratch, colorShape);
	        }
        } else {
        	if (currentType == TRIANGLE) {
	        	outerTriangle.draw(scratch, winBorder);
	        	innerTriangle.draw(scratch, winShape);
	        } else if (currentType == SQUARE) {
	        	outerSquare.draw(scratch, winBorder);
	        	innerSquare.draw(scratch, winShape);
	        } else {
	        	outerCircle.draw(scratch, winBorder);
	        	innerCircle.draw(scratch, winShape);
	        }
        }
    }

    @Override
    public void onSurfaceChanged(GL10 unused, int width, int height) {
        GLES20.glViewport(0, 0, width, height);

        float ratio = (float) width / height;

        // this projection matrix is applied to object coordinates
        // in the onDrawFrame() method
        Matrix.frustumM(mProjectionMatrix, 0, -ratio, ratio, -1, 1, 3, 7);
    }
    
    public static int loadShader(int type, String shaderCode){

        // create a vertex shader type (GLES20.GL_VERTEX_SHADER)
        // or a fragment shader type (GLES20.GL_FRAGMENT_SHADER)
        int shader = GLES20.glCreateShader(type);

        // add the source code to the shader and compile it
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);

        return shader;
    }
    
    public static void checkGlError(String glOperation) {
        int error;
        while ((error = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
            Log.e(TAG, glOperation + ": glError " + error);
            throw new RuntimeException(glOperation + ": glError " + error);
        }
    }
    
    /**
     * Returns the rotation angle of the triangle shape (mTriangle).
     *
     * @return - A float representing the rotation angle.
     */
    public float getAngle() {
        return mAngle;
    }

    /**
     * Sets the rotation angle of the triangle shape (mTriangle).
     */
    public void setVelocityAndAngle(float dx, float dy, float angle) {
        mAngle = angle;
        this.eyeX = dx;
        this.eyeY = dy;
    }
    
    public void setWinColor() {
    	isSetWin = true;
    }
    
    public void resetColor() {
    	isSetWin = false;
    }
}
