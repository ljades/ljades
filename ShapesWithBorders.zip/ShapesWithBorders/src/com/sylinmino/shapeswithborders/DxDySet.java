package com.sylinmino.shapeswithborders;

public class DxDySet {
	private int type = 0;
	private double angle = 0.0;
	
	public static final int VERTICAL = 1;
	public static final int HORIZONTAL = 2;
	public static final int SPIN = 4;
	public static final int SPIN_COUNTER = 8;
	
	public DxDySet(int type) {
		this.type = type;
	}
	
	public void setType(int type) {
		this.type = type;
		angle = 0.0;
	}
	
	public void getMovement(float[] outputV, float time, float rate) {
		if (outputV.length < 3) {
			return;
		}
		float nlgnRate = rate * (float)Math.log(rate + 1);
		/*if (type % 2 == 1) {
			outputV[0] = (float)(0.0005f * nlgnRate * Math.sin(0.025f * Math.log10(rate + 10) * time));
		} else {
			outputV[0] = 0;
		}
		if ((type % 4) >= 2) {
			outputV[1] = (float)(0.0005f * nlgnRate * Math.cos(0.02f * Math.log10(rate + 10) * time));
		} else {
			outputV[1] = 0;
		}
		if ((type % 8 >= 4) && type < 8) {
			angle += nlgnRate / 30.0f;
			outputV[2] = (float)angle;
		} else if ((type % 8 >= 4) && type >= 8) {
			angle -= nlgnRate / 30.0f;
			outputV[2] = (float)(angle);
		}*/
		if (type == 0) {
			outputV[0] = (float)(0.0005f * nlgnRate * Math.sin(0.025f * Math.log10(rate + 10) * time));
			outputV[1] = 0;
		} else if (type == 1) {
			outputV[0] = 0;
			outputV[1] = (float)(0.0005f * nlgnRate * Math.cos(0.02f * Math.log10(rate + 10) * time));
		} else if (type == 2) {
			outputV[0] = 0;
			outputV[1] = 0;
			angle += nlgnRate / 30.0f;
		} else if (type == 3) {
			outputV[0] = 0;
			outputV[1] = 0;
			angle -= nlgnRate / 30.0f;
		} else if (type == 4) {
			outputV[0] = (float)(0.0003f * nlgnRate * Math.sin(0.025f * Math.log10(rate + 10) * time));
			outputV[1] = (float)(0.0003f * nlgnRate * Math.cos(0.02f * Math.log10(rate + 10) * time));
		} else if (type == 5) {
			outputV[0] = (float)(0.0004f * nlgnRate * Math.sin(0.025f * Math.log10(rate + 10) * time));
			outputV[1] = 0;
			angle += nlgnRate / 35.0f;
		} else if (type == 6) {
			outputV[0] = (float)(0.0004f * nlgnRate * Math.sin(0.025f * Math.log10(rate + 10) * time));
			outputV[1] = 0;
			angle -= nlgnRate / 35.0f;
		} else if (type == 7) {
			outputV[0] = 0;
			outputV[1] = (float)(0.0004f * nlgnRate * Math.cos(0.02f * Math.log10(rate + 10) * time));
			angle += nlgnRate / 35.0f;
		} else if (type == 8) {
			outputV[0] = 0;
			outputV[1] = (float)(0.0004f * nlgnRate * Math.cos(0.02f * Math.log10(rate + 10) * time));
			angle -= nlgnRate / 35.0f;
		} else if (type == 9) {
			outputV[0] = (float)(0.00025f * nlgnRate * Math.sin(0.025f * Math.log10(rate + 10) * time));
			outputV[1] = (float)(0.00025f * nlgnRate * Math.cos(0.02f * Math.log10(rate + 10) * time));
			angle += nlgnRate / 45.0f;
		} else {
			outputV[0] = (float)(0.00025f * nlgnRate * Math.sin(0.025f * Math.log10(rate + 10) * time));
			outputV[1] = (float)(0.00025f * nlgnRate * Math.cos(0.02f * Math.log10(rate + 10) * time));
			angle -= nlgnRate / 45.0f;
		}
		outputV[2] = (float)angle;
	}
}
