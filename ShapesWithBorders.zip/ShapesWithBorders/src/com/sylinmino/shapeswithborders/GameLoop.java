package com.sylinmino.shapeswithborders;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;

public class GameLoop extends Activity {

    private MyGLSurfaceView mGLView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Create a GLSurfaceView instance and set it
        // as the ContentView for this Activity.
        mGLView = new MyGLSurfaceView(this);
        setContentView(mGLView);

    }
    
    
    
    private void exitGame() {
    	Intent intent = new Intent(this, ScoreScreenActivity.class);
        intent.putExtra(MyGLSurfaceView.EXTRA_SCORE, mGLView.getLevel());
        startActivity(intent);
    }

}
