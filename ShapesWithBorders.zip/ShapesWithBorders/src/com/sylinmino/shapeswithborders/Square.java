package com.sylinmino.shapeswithborders;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;


import android.opengl.GLES20;

public class Square {

	private final String vertexShaderCode =
            // This matrix member variable provides a hook to manipulate
            // the coordinates of the objects that use this vertex shader
            "uniform mat4 uMVPMatrix;" +
            "attribute vec4 vPosition;" +
            "void main() {" +
            // The matrix must be included as a modifier of gl_Position.
            // Note that the uMVPMatrix factor *must be first* in order
            // for the matrix multiplication product to be correct.
            "  gl_Position = uMVPMatrix * vPosition;" +
            "}";

    private final String fragmentShaderCode =
            "precision mediump float;" +
            "uniform vec4 vColor;" +
            "void main() {" +
            "  gl_FragColor = vColor;" +
            "}";
	
    private FloatBuffer vertexBuffer;
    private ShortBuffer drawListBuffer;

    // number of coordinates per vertex in this array
    static final int COORDS_PER_VERTEX = 3;
    private float stockSquareCoords[] = {
            -0.5f,  0.5f, 0.0f,   // top left
            -0.5f, -0.5f, 0.0f,   // bottom left
             0.5f, -0.5f, 0.0f,   // bottom right
             0.5f,  0.5f, 0.0f }; // top right
    private float []squareCoords;
    private short drawOrder[] = { 0, 1, 2, 0, 2, 3 }; // order to draw vertices
    
    private final int mProgram;
    private int mPositionHandle;
    private int mColorHandle;
    private int mMVPMatrixHandle;
    
    private final int vertexStride = COORDS_PER_VERTEX * 4; // 4 bytes per vertex

    public Square(float scale) {
    	squareCoords = new float[stockSquareCoords.length];
    	for (int i = 0; i < 12; i++) {
    		squareCoords[i] = stockSquareCoords[i] * scale;
    	}
        // initialize vertex byte buffer for shape coordinates
        ByteBuffer bb = ByteBuffer.allocateDirect(
        // (# of coordinate values * 4 bytes per float)
                squareCoords.length * 4);
        bb.order(ByteOrder.nativeOrder());
        vertexBuffer = bb.asFloatBuffer();
        vertexBuffer.put(squareCoords);
        vertexBuffer.position(0);

        // initialize byte buffer for the draw list
        ByteBuffer dlb = ByteBuffer.allocateDirect(
        // (# of coordinate values * 2 bytes per short)
                drawOrder.length * 2);
        dlb.order(ByteOrder.nativeOrder());
        drawListBuffer = dlb.asShortBuffer();
        drawListBuffer.put(drawOrder);
        drawListBuffer.position(0);
        
        int vertexShader = MyGLRenderer.loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode);
        int fragmentShader = MyGLRenderer.loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode);

        mProgram = GLES20.glCreateProgram();             // create empty OpenGL ES Program
        GLES20.glAttachShader(mProgram, vertexShader);   // add the vertex shader to program
        GLES20.glAttachShader(mProgram, fragmentShader); // add the fragment shader to program
        GLES20.glLinkProgram(mProgram);                  // creates OpenGL ES program executables
    }
    
    
    public void draw(float[] mvpMatrix, float[] color) {
        // Add program to OpenGL environment
        GLES20.glUseProgram(mProgram);

        // get handle to vertex shader's vPosition member
        mPositionHandle = GLES20.glGetAttribLocation(mProgram, "vPosition");

        // Enable a handle to the triangle vertices
        GLES20.glEnableVertexAttribArray(mPositionHandle);

        // Prepare the triangle coordinate data
        GLES20.glVertexAttribPointer(
                mPositionHandle, COORDS_PER_VERTEX,
                GLES20.GL_FLOAT, false,
                vertexStride, vertexBuffer);

        // get handle to fragment shader's vColor member
        mColorHandle = GLES20.glGetUniformLocation(mProgram, "vColor");

        // Set color for drawing the triangle
        GLES20.glUniform4fv(mColorHandle, 1, color, 0);

        // get handle to shape's transformation matrix
        mMVPMatrixHandle = GLES20.glGetUniformLocation(mProgram, "uMVPMatrix");
        MyGLRenderer.checkGlError("glGetUniformLocation");

        // Apply the projection and view transformation
        GLES20.glUniformMatrix4fv(mMVPMatrixHandle, 1, false, mvpMatrix, 0);
        MyGLRenderer.checkGlError("glUniformMatrix4fv");

        // Draw the square
        GLES20.glDrawElements(
                GLES20.GL_TRIANGLES, drawOrder.length,
                GLES20.GL_UNSIGNED_SHORT, drawListBuffer);

        // Disable vertex array
        GLES20.glDisableVertexAttribArray(mPositionHandle);
    }
    
    
    private float sign(float p1x, float p1y, float p2x, float p2y, float p3x, float p3y) {
    	return (p1x - p3x) * (p2y - p3y) - (p2x - p3x) * (p1y - p3y);
    }
      
    public Boolean isIntersection(float mouseX, float mouseY) {
      	Boolean b1, b2, b3, b4, b5, b6;
      	
      	b1 = sign(mouseX, mouseY, squareCoords[0], squareCoords[1], squareCoords[3], squareCoords[4]) < 0.0f;
      	b2 = sign(mouseX, mouseY, squareCoords[3], squareCoords[4], squareCoords[6], squareCoords[7]) < 0.0f;
      	b3 = sign(mouseX, mouseY, squareCoords[6], squareCoords[7], squareCoords[0], squareCoords[1]) < 0.0f;
      	
      	b4 = sign(mouseX, mouseY, squareCoords[0], squareCoords[1], squareCoords[6], squareCoords[7]) < 0.0f;
      	b5 = sign(mouseX, mouseY, squareCoords[6], squareCoords[7], squareCoords[9], squareCoords[10]) < 0.0f;
      	b6 = sign(mouseX, mouseY, squareCoords[9], squareCoords[10], squareCoords[0], squareCoords[1]) < 0.0f;
      	
      	return ((b1 == b2) && (b2 == b3)) || ((b4 == b5) && (b5 == b6));
    }
}
