package com.sylinmino.shapeswithborders;


import java.util.Random;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.os.SystemClock;
import android.view.MotionEvent;

public class MyGLSurfaceView extends GLSurfaceView {
	
    private final MyGLRenderer mRenderer;
    private MainThread thread;
    public double max_count = 1.0;
    public double countdown;
    public boolean hasStarted = false;
    private boolean validTouch = false;
    private int level;
    public final static String EXTRA_SCORE = "com.sylinmino.shapeswithborders.SCORE";
    public boolean isLose = false;
    public boolean isPause = false;
    private Random patternRand = new Random();
    
    private DxDySet pattern = new DxDySet(patternRand.nextInt(12));
    
    private Random levelRand = new Random();
    
    //private int [] textures;
    
    public int getLevel() {
    	return level;
    }
    
	public boolean updateAndDraw(long tick) {
		if (hasStarted) {
			float [] setOfMove = new float[3];
			pattern.getMovement(setOfMove, tick, (float)level);
			mRenderer.setVelocityAndAngle(setOfMove[0], setOfMove[1], setOfMove[2]);
			requestRender();
		}
		return mRenderer.threadIntersect();
	}
	
	public void redifyBackground(float maxHealth, float currHealth) {
		float diff = (maxHealth - currHealth);
		//System.out.println("Changing background");
		//mRenderer.setBackground(0.2f, 0.8f, 0.0f, 1.0f);
		mRenderer.setBackground(0.7f + (0.2f * diff), 0.7f - (0.2f * diff), 1.0f - (0.1f * diff), 1.0f);
	}
	
	public void downTime(long FPS) {
		if (hasStarted && validTouch) {
			countdown -= 1.0 / (double)FPS;
		}
		if (countdown <= 0.000001) {
			isPause = true;
			level++;
			countdown = max_count;
			isLose = false;
			hasStarted = false;
			validTouch = false;
			//TODO: Display temporary wintext, delay time for two seconds
			mRenderer.setWinColor();
			requestRender();
			SystemClock.sleep(700L);
			mRenderer.resetColor();
			mRenderer.setType((short)levelRand.nextInt(3));
			pattern.setType(patternRand.nextInt(12));
			mRenderer.setVelocityAndAngle(0, 0, 0);
			isPause = false;
		}
	}
    
    public MyGLSurfaceView(Context context){
        super(context);
        setEGLContextClientVersion(2);
        // Set the Renderer for drawing on the GLSurfaceView
        mRenderer = new MyGLRenderer();
        mRenderer.setType((short)0);
        setRenderer(mRenderer);
        //setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
        countdown = max_count;
        hasStarted = false;
        level = 0;
        setFocusable(true);
        requestRender();
        thread = new MainThread(this, context);
        thread.setRunning(true);
        thread.start();
    }
    
    
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        // MotionEvent reports input details from the touch screen
        // and other input controls. In this case, you are only
        // interested in events where the touch position changed.
    	if (e.getAction() == MotionEvent.ACTION_DOWN) {
    		System.out.println("I felt that!");
    	} else if (e.getAction() == MotionEvent.ACTION_POINTER_UP || e.getAction() == MotionEvent.ACTION_UP) {
    		validTouch = false;
    	}
    	if (e.getPointerCount() > 1) {
    		float onefinger[] = {0.0f, 0.0f};
    		float twofinger[] = {0.0f, 0.0f};
    		onefinger[0] = 2.0f * (e.getX(0) - (getWidth() / 2.0f )) / (float)getWidth();
    		onefinger[1] = 2.0f * (-e.getY(0) + (getHeight() / 2.0f)) / (float)getHeight();
    		/*System.out.println("Finger one: ");
    		System.out.print(onefinger[0]);
    		System.out.print(' ');
    		System.out.print(onefinger[1]);*/
    		twofinger[0] = 2.0f * (e.getX(1) - (getWidth() / 2.0f)) / (float)getWidth();
    		twofinger[1] = 2.0f * (-e.getY(1) + (getHeight() / 2.0f)) / (float)getHeight();
    		/*System.out.println("Finger two: ");
    		System.out.print(twofinger[0]);
    		System.out.print(' ');
    		System.out.print(twofinger[1]);*/
    		mRenderer.setPointers(onefinger, twofinger);
    		boolean isDead = mRenderer.checkIntersect(onefinger) && mRenderer.checkIntersect(twofinger);
    		if (isDead) {
    			//System.out.println("You got the border.");
    			validTouch = true;
    		}
    		if (hasStarted == false && validTouch == true && !isPause ) {
    			hasStarted = true;
    		}
    	} else {
    		if (hasStarted == true) {
    			//TODO: death condition
    			validTouch = false;
    		}
    	}
        
        return true;
    }
}
