package com.sylinmino.shapeswithborders;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

public class MainThread extends Thread {

	private static final String TAG = MainThread.class.getSimpleName();
	public final static String EXTRA_SCORE = "com.sylinmino.shapeswithborders.SCORE";
	
	private MyGLSurfaceView gamePanel;
	private boolean running = false;
	
	private Context theActivity;
	
	public void setRunning(boolean running) {
		this.running = running;
	}

	public MainThread(MyGLSurfaceView gamePanel, Context context) {
		super();
		this.gamePanel = gamePanel;
		theActivity = context;
	}
 
	@Override
	public void run() {
		long tickCount = 0L;
		float max_health = 6.0f;
		float health = max_health;
		Log.d(TAG, "Starting game loop");
		System.out.println("Starting the game loop.");
		long FPS = 80L;
        long delayFPS = 1000L / FPS;
		while (running) {
			if (gamePanel.hasStarted) {
				
				tickCount++;
	        	SystemClock.sleep(delayFPS);
	        	
	        	if (gamePanel.updateAndDraw(tickCount) == false && !gamePanel.isPause) {
	        		health -= 0.1f;
	        		gamePanel.redifyBackground(max_health, health);
	        		if (health < 0) {
	        			running = false;
	        		}
	        	}
	        	gamePanel.downTime(FPS);
			} else {
				health = max_health;
				gamePanel.redifyBackground(max_health, health);
			}
	    }
		System.out.println("Finished the game loop.");
		Log.d(TAG, "Game loop executed " + tickCount + " times");
		Handler handler = new Handler(Looper.getMainLooper());
		handler.post(new Runnable() {
		    @Override
		    public void run() {
		        Intent intent = new Intent (theActivity, ScoreScreenActivity.class);
		        intent.putExtra(MyGLSurfaceView.EXTRA_SCORE, gamePanel.getLevel());
		        theActivity.startActivity(intent);
		    }
		});
		
	}
}
