package com.sylinmino.shapeswithborders;

import android.os.SystemClock;
import android.util.Log;

public class MainThread extends Thread {

	private static final String TAG = MainThread.class.getSimpleName();
	
	private MyGLSurfaceView gamePanel;
	private boolean running = false;
	
	public void setRunning(boolean running) {
		this.running = running;
	}

	public MainThread(MyGLSurfaceView gamePanel) {
		super();
		this.gamePanel = gamePanel;
	}
 
	@Override
	public void run() {
		long tickCount = 0L;
		float health = 7.0f;
		Log.d(TAG, "Starting game loop");
		System.out.println("Starting the game loop.");
		long FPS = 80L;
        long delayFPS = 1000L / FPS;
		while (running) {
			if (gamePanel.hasStarted) {
				tickCount++;
	        	SystemClock.sleep(delayFPS);
	        	
	        	if (gamePanel.updateAndDraw(tickCount) == false) {
	        		health -= 0.1f;
	        		gamePanel.redifyBackground(7.0f, health);
	        		if (health < 0) {
	        			running = false;
	        		}
	        	}
	        	gamePanel.downTime(FPS);
			} else {
				health = 7.0f;
				gamePanel.redifyBackground(7.0f, health);
			}
	    }
		System.out.println("Finished the game loop.");
		Log.d(TAG, "Game loop executed " + tickCount + " times");
		
	}
}
