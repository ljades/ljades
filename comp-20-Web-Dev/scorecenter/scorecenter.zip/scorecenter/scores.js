var express = require('express');
//var app = express.createServer(express.logger());
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');

// Mongo initialization

var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/scorecenter';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
	db = databaseConnection;
});

app.post('/submit.json', function(request, response){
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	
	response.set('Content-Type', 'text/json');
	var data = new Object();
	data.game_title = request.body.game_title;
	data.username = request.body.username;
	data.score = parseInt(request.body.score);
	/*cool_date = new Date();
	data.created_at = "" + (cool_date.getMonth() + 1) + "/" + cool_date.getDate() + "/" + cool_date.getFullYear() + " " + cool_date.getHours() + ":" + cool_date.getMinutes();*/
	data.created_at = new Date();
	db.collection('highscores', function(er, collection) {
		collection.insert({"username":data.username,"game_title":data.game_title,"score":data.score, "created_at":data.created_at.toString()}, function(err, docs) {
			if (err) {
				response.send("Whoops, something went terribly wrong!");
			}
			else {
				response.send("OK");
			}
		});
	});
});



app.get('/highscores.json', function(request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");

	response.set('Content-Type', 'text/json');
	if(typeof(request.query.game_title) == "undefined")
	{
		db.collection('highscores', function(er, collection) {
			collection.find().sort({score:-1}).limit(10).toArray(function(err, cursor) {
				var sendString = "[";
				if (!err) {
					for (var count = 0; count < cursor.length; count++) {
						sendString = sendString + "{'game_title':'" + cursor[count].game_title + "','username':'" + cursor[count].username + "','score':'" + cursor[count].score + "','created_at':'" + cursor[count].created_at + "'}";
						if(count != cursor.length - 1)
							sendString = sendString + ", ";
					}	
				}
				sendString = sendString + "]";
				response.send(sendString);
			}
	  )});
	}
	else
	{
		db.collection('highscores', function(er, collection) {
			collection.find({game_title: request.query.game_title}).sort({score: -1 }).limit(10).toArray(function(err, cursor) {
				var sendString = "[";
				if (!err) {
					for (var count = 0; count < cursor.length; count++) {
						sendString = sendString + "{'game_title':'" + cursor[count].game_title + "','username':'" + cursor[count].username + "','score':'" + cursor[count].score + "','created_at':'" + cursor[count].created_at + "'}";
						if(count != cursor.length - 1)
							sendString = sendString + ", ";
					}	
				}
				sendString = sendString + "]";
				response.send(sendString);
			}
		)});
	}
});


app.get('/usersearch', function(request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");

	response.send("<form name='search' action='/getuserstuff' method='post'>Username: <input type='text' name='username'><input type='submit' value='Submit'></form>");
	
});

app.post('/getuserstuff', function(request, response){
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	db.collection('highscores', function(er, collection) {
		collection.find({username: request.body.username}).toArray(function(err, cursor) {
			var sendString = "";
			if (!err) {
				for (var count = 0; count < cursor.length; count++) {
					sendString = sendString + "Game Title - " + cursor[count].game_title + ". Score: " + cursor[count].score + ". Created at: " + cursor[count].created_at + ". <br/>";
					}	//deliberately left username out of the results, as they all have the requested one.
				}
				
				response.send("<h1>Your Scores</h1><br/>" + sendString);
			}
	  )});


});



app.listen(process.env.PORT || 3000);

app.get('/', function (request, response) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");

	db.collection('highscores', function(er, collection) {
		collection.find().sort({game_title: 1, score: -1}).toArray(function(err, cursor) {
			var sendString = "";
			if (!err) {
				for (var count = 0; count < cursor.length; count++) {
					sendString = sendString + "Game Title - " + cursor[count].game_title + ". Username - " + cursor[count].username + ". Score: " + cursor[count].score + ". Created at: " + cursor[count].created_at + ". <br/>";
					}	
				}
				
				response.send("<h1>All Scores</h1><br/>" + sendString);
			}
	  )});	
	
});