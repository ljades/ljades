My app is just way too peculiar. I tried to implement everything. Insert is the only thingthat goes off without a hitch.
All get requests give me server timeouts. I don't know why--I used the syntax I was
given. I hope not as many points can get deducted if it's a small common problem going
throughout. It doesn't make any sense to me--I used all resources available.

This assignment took me a ton of time (I can't count how many hours I spent reading
documentation and trying to fix errors).

I gave and received a bit of advice from others in the class (such as Brett Fischler and Caleb Malchik), and from you.
However, I never exactly collaborated with anyone for an extended period of time, nor
had anyone hard code my stuff.